package com.example.task7_1;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class AdvertList extends AppCompatActivity {

    RecyclerView recyclerView;
    VerticalAdapter adapter;
    AdvertDB advertDB;
    List<Advert> advertList;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.lnf_list_activity);
        recyclerView = findViewById(R.id.recyclerView);
        advertDB = new AdvertDB(this);
        createLostAndFoundList();
    }
    @Override
    protected void onResume() {
        super.onResume();
        createLostAndFoundList();
    }
    private void createLostAndFoundList() {
        advertList = advertDB.getAllAdverts();
        adapter = new VerticalAdapter(advertList, new OnItemClickListener() {
            @Override public void onItemClick(Advert advert) {
                Intent intent = new Intent(AdvertList.this, AdvertDetails.class);
                intent.putExtra("id", advert.getId());
                startActivity(intent);
            }
        });
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setAdapter(adapter);
    }



    public class VerticalAdapter extends RecyclerView.Adapter<VerticalAdapter.ViewHolder> {

        private List<Advert> advertList;
        private final OnItemClickListener listener;

        public VerticalAdapter(List<Advert> advertList, OnItemClickListener listener) {
            this.advertList = advertList;
            this.listener = listener;
        }

        public class ViewHolder extends RecyclerView.ViewHolder {
            private TextView titleTextView;
            private TextView typeTV;

            public ViewHolder(View itemView) {
                super(itemView);
                titleTextView = itemView.findViewById(R.id.titleTV);
                typeTV = itemView.findViewById(R.id.typeTV);
            }

            public void bind(Advert advert, final OnItemClickListener listener) {
                titleTextView.setText(advert.getName());
                typeTV.setText(advert.getLostType() ? "Lost" : "Found" );
                itemView.setOnClickListener(new View.OnClickListener() {
                    @Override public void onClick(View v) {
                        listener.onItemClick(advert);
                    }
                });
            }
        }
        @NonNull
        @Override
        public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.lnf_item, parent, false);
            return new ViewHolder(view);
        }

        @Override
        public void onBindViewHolder(ViewHolder holder, int position) {
            Advert advert = advertList.get(position);
            holder.bind(advert, listener);
        }

        @Override
        public int getItemCount() {
            if(this.advertList == null) {
                System.out.println("getItemCount advertList is NULL");
                return 0;
            }
            return this.advertList.size();
        }
    }
}
