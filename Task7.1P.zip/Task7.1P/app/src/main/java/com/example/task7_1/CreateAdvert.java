package com.example.task7_1;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.UUID;

public class CreateAdvert extends AppCompatActivity {

    RadioGroup radioGroup;
    TextView header;
    RadioButton lostRadio;
    RadioButton foundRadio;
    EditText nameET;
    EditText phoneET;
    EditText descriptionET;
    EditText dateET;
    EditText locationET;
    Button saveButton;

    Boolean postTypeLost = true;

    AdvertDB advertDB;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.create_advert);
        radioGroup = findViewById(R.id.radioGroup);
        header = findViewById(R.id.header);
        foundRadio = findViewById(R.id.radioFound);
        lostRadio = findViewById(R.id.radioLost);
        nameET = findViewById(R.id.nameET);
        phoneET = findViewById(R.id.phoneET);
        descriptionET = findViewById(R.id.descriptionET);
        dateET = findViewById(R.id.dateET);
        locationET = findViewById(R.id.locationET);
        saveButton = findViewById(R.id.saveButton);
        advertDB = new AdvertDB(this);
        saveButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String name = nameET.getText().toString();
                if (name == "") {
                    Toast.makeText(CreateAdvert.this, "Name not entered",
                            Toast.LENGTH_SHORT).show();
                    return;
                }
                String phone = phoneET.getText().toString();
                if (phone == "") {
                    Toast.makeText(CreateAdvert.this, "Phone not entered",
                            Toast.LENGTH_SHORT).show();
                    return;
                }
                String description = descriptionET.getText().toString();
                if (description == "") {
                    Toast.makeText(CreateAdvert.this, "Description not entered",
                            Toast.LENGTH_SHORT).show();
                    return;
                }
                String date = dateET.getText().toString();
                if (date == "") {
                    Toast.makeText(CreateAdvert.this, "Date not entered",
                            Toast.LENGTH_SHORT).show();
                    return;
                }
                String location = locationET.getText().toString();
                if (location == "") {
                    Toast.makeText(CreateAdvert.this, "Location not entered",
                            Toast.LENGTH_SHORT).show();
                    return;
                }

                if(postTypeLost == null){
                    Toast.makeText(CreateAdvert.this, "Post type not selected",
                            Toast.LENGTH_SHORT).show();
                    return;
                }

                Advert advert = new Advert(UUID.randomUUID().toString(),postTypeLost, name,phone,description, date, location);
                Boolean success = advertDB.addAdvert(advert);
                if (success) {
                    Toast.makeText(CreateAdvert.this, "Advert added successfully",
                            Toast.LENGTH_SHORT).show();
                    nameET.setText("");
                    phoneET.setText("");
                    dateET.setText("");
                    locationET.setText("");
                    descriptionET.setText("");
                    dateET.setText("");
                } else {
                    Toast.makeText(CreateAdvert.this, "Advert database error",
                            Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    public void onRadioButtonClicked(View view) {
        boolean checked = ((RadioButton) view).isChecked();
        switch(view.getId()) {
            case R.id.radioLost:
                if (checked)
                    postTypeLost = true;
                break;
            case R.id.radioFound:
                if (checked)
                    postTypeLost = false;
                break;
        }
    }
}