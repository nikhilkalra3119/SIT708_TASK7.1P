package com.example.task7_1;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class AdvertDetails extends AppCompatActivity {
    TextView typeTV;
    TextView nameTV;
    TextView phoneTV;
    TextView descriptionTV;
    TextView locationTV;
    TextView dateTV;
    Button removeButton;
    Advert advert;
    AdvertDB advertDB;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.lnf_item_details);
        advertDB = new AdvertDB(this);
        typeTV = findViewById(R.id.typeTV);
        nameTV = findViewById(R.id.nameTV);
        phoneTV = findViewById(R.id.phoneTV);
        descriptionTV = findViewById(R.id.descriptionTV);
        dateTV = findViewById(R.id.dateTV);
        locationTV = findViewById(R.id.locationTV);
        removeButton = findViewById(R.id.removeButton);
        String id = getIntent().getStringExtra("id");
        advert = advertDB.getAdvert(id);

        typeTV.setText(advert.getLostType() ? "Lost" : "Found");
        nameTV.setText("Name: " + advert.getName());
        phoneTV.setText("Phone: " + advert.getPhone());
        descriptionTV.setText("Description: " + advert.getDescription());
        dateTV.setText("Date: " + advert.getDate());
        locationTV.setText("Location: " + advert.getLocation());

        removeButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Boolean result = advertDB.deleteAdvert(id);
                if (result) {
                    Toast.makeText(AdvertDetails.this, "Successfully deleted item",
                            Toast.LENGTH_SHORT).show();
                    AdvertDetails.this.finish();
                } else {
                    Toast.makeText(AdvertDetails.this, "Item deletion error",
                            Toast.LENGTH_SHORT).show();
                }
                            }
        });
    }

}

