package com.example.task7_1;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import java.util.ArrayList;
import java.util.List;


public class AdvertDB extends SQLiteOpenHelper {
    private static final String TABLE_NAME = "advert";

    private static final String DB_NAME = "advertDatabase.db";

    public AdvertDB(Context context) {
        super(context, DB_NAME, null, 1);
    }
    @Override
    public void onCreate(SQLiteDatabase db) {
        String sql = "CREATE TABLE advert (id TEXT PRIMARY KEY, name TEXT, lostType TEXT, phone TEXT, description TEXT, date TEXT, location TEXT)";
        db.execSQL(sql);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // handle any database schema changes in future versions of your app
    }

    public Boolean addAdvert(Advert advert) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("id", advert.getId());
        values.put("name", advert.getName());
        values.put("lostType", advert.getLostType() ? "true" : "false");
        values.put("phone", advert.getPhone());
        values.put("description", advert.getDescription());
        values.put("date", advert.getDate());
        values.put("location", advert.getLocation());

        long rowId = db.insert(TABLE_NAME, null, values);
        db.close();
        if (rowId > -1) {
            System.out.println("Data Added. Row: " + rowId);
            return true;
        } else {
            System.out.println("Database insert failed.");
            return false;
        }
    }

    public Advert getAdvert(String id) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query(TABLE_NAME, new String[] { "id", "name", "lostType", "phone", "description", "date", "location" },
                "id=?", new String[] { id }, null, null, null, null);
        if (cursor != null) {
            cursor.moveToFirst();
        }
        Advert advert = new Advert(cursor.getString(0), cursor.getString(2).equals("true")? true : false, cursor.getString(1) , cursor.getString(3), cursor.getString(4), cursor.getString(5), cursor.getString(6));
        cursor.close();
        db.close();
        return advert;
    }

    public List<Advert> getAllAdverts() {
        SQLiteDatabase db = getReadableDatabase();
        Cursor cursor = db.query(TABLE_NAME, null, null, null, null, null, null);
        List<Advert> result = new ArrayList<>();

        int i = 0;
        while (cursor.moveToNext()) {
            result.add(new Advert(cursor.getString(0), cursor.getString(2).equals("true") ? true : false, cursor.getString(1) , cursor.getString(3), cursor.getString(4), cursor.getString(5), cursor.getString(6)));
        }
        cursor.close();
        db.close();
        return result;
    }

    public Boolean deleteAdvert(String id) {
        SQLiteDatabase db = getWritableDatabase();
        String whereClause = "id" + " = ?";
        String[] whereArgs = { id };
        int numRowsDeleted = db.delete(TABLE_NAME, whereClause, whereArgs);
        db.close();
        if (numRowsDeleted > 0) {
            return true;
        } else {
            return false;
        }
    }
}
