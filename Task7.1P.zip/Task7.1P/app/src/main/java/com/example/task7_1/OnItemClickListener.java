package com.example.task7_1;

public interface OnItemClickListener {
        void onItemClick(Advert advert);
}
