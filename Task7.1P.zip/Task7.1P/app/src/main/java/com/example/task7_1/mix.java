//package com.example.task7_1;
//
//import android.content.Intent;
//import android.os.Bundle;
//import android.view.LayoutInflater;
//import android.view.View;
//import android.view.ViewGroup;
//import android.widget.Button;
//import android.widget.EditText;
//import android.widget.RadioButton;
//import android.widget.RadioGroup;
//import android.widget.TextView;
//import android.widget.Toast;
//
//import androidx.annotation.NonNull;
//import androidx.appcompat.app.AppCompatActivity;
//import androidx.recyclerview.widget.LinearLayoutManager;
//import androidx.recyclerview.widget.RecyclerView;
//
//import java.util.List;
//import java.util.UUID;
//
//public class Advert {
//    private String id;
//    private Boolean lostType;
//    private String name;
//    private String phone;
//    private String description;
//    private String date;
//    private String location;
//
//
//    public Advert(String id, Boolean lostType, String name, String phone, String description, String date, String location) {
//        this.id = id;
//        this.lostType = lostType;
//        this.name = name;
//        this.phone = phone;
//        this.description = description;
//        this.date = date;
//        this.location = location;
//    }
//
//    @Override
//    public String toString() {
//        return "Advert{" +
//                "id='" + id + '\'' +
//                ", lostType=" + lostType +
//                ", name='" + name + '\'' +
//                ", phone='" + phone + '\'' +
//                ", description='" + description + '\'' +
//                ", date='" + date + '\'' +
//                ", location='" + location + '\'' +
//                '}';
//    }
//
//    public String getId() {
//        return id;
//    }
//
//    public void setId(String id) {
//        this.id = id;
//    }
//
//    public Boolean getLostType() {
//        return lostType;
//    }
//
//    public void setLostType(Boolean lostType) {
//        this.lostType = lostType;
//    }
//
//    public String getName() {
//        return name;
//    }
//
//    public void setName(String name) {
//        this.name = name;
//    }
//
//    public String getPhone() {
//        return phone;
//    }
//
//    public void setPhone(String phone) {
//        this.phone = phone;
//    }
//
//    public String getDescription() {
//        return description;
//    }
//
//    public void setDescription(String description) {
//        this.description = description;
//    }
//
//    public String getDate() {
//        return date;
//    }
//
//    public void setDate(String date) {
//        this.date = date;
//    }
//
//    public String getLocation() {
//        return location;
//    }
//
//    public void setLocation(String location) {
//        this.location = location;
//    }
//}
//
//package com.example.task7_1;
//
//        import androidx.appcompat.app.AppCompatActivity;
//
//        import android.content.Intent;
//        import android.os.Bundle;
//        import android.view.View;
//        import android.widget.Button;
//
//public class MainActivity extends AppCompatActivity {
//
//    Button newAdvertButton;
//    Button lafButton;
//    @Override
//    protected void onCreate(Bundle savedInstanceState) {
//        super.onCreate(savedInstanceState);
//        setContentView(R.layout.activity_main);
//        newAdvertButton = findViewById(R.id.newAdvertButton);
//        lafButton = findViewById(R.id.lafButton);
//        newAdvertButton.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                Intent i= new Intent(MainActivity.this,CreateAdvert.class);
//                startActivity(i);
//            }
//        });
//        lafButton.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                Intent i= new Intent(MainActivity.this,AdvertList.class);
//                startActivity(i);
//            }
//        });
//    }
//}
//
//package com.example.task7_1;
//
//        import android.os.Bundle;
//        import android.view.View;
//        import android.widget.Button;
//        import android.widget.EditText;
//        import android.widget.RadioButton;
//        import android.widget.RadioGroup;
//        import android.widget.TextView;
//        import android.widget.Toast;
//
//        import androidx.appcompat.app.AppCompatActivity;
//
//        import java.util.UUID;
//
//public class CreateAdvert extends AppCompatActivity {
//
//    RadioGroup radioGroup;
//    TextView header;
//    RadioButton lostRadio;
//    RadioButton foundRadio;
//    EditText nameET;
//    EditText phoneET;
//    EditText descriptionET;
//    EditText dateET;
//    EditText locationET;
//    Button saveButton;
//
//    Boolean postTypeLost = true;
//
//    AdvertDB advertDB;
//
//    @Override
//    protected void onCreate(Bundle savedInstanceState) {
//        super.onCreate(savedInstanceState);
//        setContentView(R.layout.create_advert);
//        radioGroup = findViewById(R.id.radioGroup);
//        header = findViewById(R.id.header);
//        foundRadio = findViewById(R.id.radioFound);
//        lostRadio = findViewById(R.id.radioLost);
//        nameET = findViewById(R.id.nameET);
//        phoneET = findViewById(R.id.phoneET);
//        descriptionET = findViewById(R.id.descriptionET);
//        dateET = findViewById(R.id.dateET);
//        locationET = findViewById(R.id.locationET);
//        saveButton = findViewById(R.id.saveButton);
//        advertDB = new AdvertDB(this);
//        saveButton.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                String name = nameET.getText().toString();
//                if (name == "") {
//                    Toast.makeText(CreateAdvert.this, "Name not entered",
//                            Toast.LENGTH_SHORT).show();
//                    return;
//                }
//                String phone = phoneET.getText().toString();
//                if (phone == "") {
//                    Toast.makeText(CreateAdvert.this, "Phone not entered",
//                            Toast.LENGTH_SHORT).show();
//                    return;
//                }
//                String description = descriptionET.getText().toString();
//                if (description == "") {
//                    Toast.makeText(CreateAdvert.this, "Description not entered",
//                            Toast.LENGTH_SHORT).show();
//                    return;
//                }
//                String date = dateET.getText().toString();
//                if (date == "") {
//                    Toast.makeText(CreateAdvert.this, "Date not entered",
//                            Toast.LENGTH_SHORT).show();
//                    return;
//                }
//                String location = locationET.getText().toString();
//                if (location == "") {
//                    Toast.makeText(CreateAdvert.this, "Location not entered",
//                            Toast.LENGTH_SHORT).show();
//                    return;
//                }
//
//                if(postTypeLost == null){
//                    Toast.makeText(CreateAdvert.this, "Post type not selected",
//                            Toast.LENGTH_SHORT).show();
//                    return;
//                }
//
//                Advert advert = new Advert(UUID.randomUUID().toString(),postTypeLost, name,phone,description, date, location);
//                Boolean success = advertDB.addAdvert(advert);
//                if (success) {
//                    Toast.makeText(CreateAdvert.this, "Advert added successfully",
//                            Toast.LENGTH_SHORT).show();
//                    nameET.setText("");
//                    phoneET.setText("");
//                    dateET.setText("");
//                    locationET.setText("");
//                    descriptionET.setText("");
//                    dateET.setText("");
//                } else {
//                    Toast.makeText(CreateAdvert.this, "Advert database error",
//                            Toast.LENGTH_SHORT).show();
//                }
//            }
//        });
//    }
//
//    public void onRadioButtonClicked(View view) {
//        boolean checked = ((RadioButton) view).isChecked();
//        switch(view.getId()) {
//            case R.id.radioLost:
//                if (checked)
//                    postTypeLost = true;
//                break;
//            case R.id.radioFound:
//                if (checked)
//                    postTypeLost = false;
//                break;
//        }
//    }
//}
//package com.example.task7_1;
//
//        import android.content.Intent;
//        import android.os.Bundle;
//        import android.util.Log;
//        import android.view.LayoutInflater;
//        import android.view.View;
//        import android.view.ViewGroup;
//        import android.widget.AdapterView;
//        import android.widget.TextView;
//
//        import androidx.annotation.NonNull;
//        import androidx.appcompat.app.AppCompatActivity;
//        import androidx.recyclerview.widget.LinearLayoutManager;
//        import androidx.recyclerview.widget.RecyclerView;
//
//        import java.util.List;
//
//public class AdvertList extends AppCompatActivity {
//
//    RecyclerView recyclerView;
//    VerticalAdapter adapter;
//    AdvertDB advertDB;
//    List<Advert> advertList;
//    @Override
//    protected void onCreate(Bundle savedInstanceState) {
//        super.onCreate(savedInstanceState);
//        setContentView(R.layout.lnf_list_activity);
//        recyclerView = findViewById(R.id.recyclerView);
//        advertDB = new AdvertDB(this);
//        createLostAndFoundList();
//    }
//    @Override
//    protected void onResume() {
//        super.onResume();
//        createLostAndFoundList();
//    }
//    private void createLostAndFoundList() {
//        advertList = advertDB.getAllAdverts();
//        adapter = new VerticalAdapter(advertList, new OnItemClickListener() {
//            @Override public void onItemClick(Advert advert) {
//                Intent intent = new Intent(AdvertList.this, AdvertDetails.class);
//                intent.putExtra("id", advert.getId());
//                startActivity(intent);
//            }
//        });
//        recyclerView.setLayoutManager(new LinearLayoutManager(this));
//        recyclerView.setAdapter(adapter);
//    }
//
//
//
//    public class VerticalAdapter extends RecyclerView.Adapter<VerticalAdapter.ViewHolder> {
//
//        private List<Advert> advertList;
//        private final OnItemClickListener listener;
//
//        public VerticalAdapter(List<Advert> advertList, OnItemClickListener listener) {
//            this.advertList = advertList;
//            this.listener = listener;
//        }
//
//        public class ViewHolder extends RecyclerView.ViewHolder {
//            private TextView titleTextView;
//            private TextView typeTV;
//
//            public ViewHolder(View itemView) {
//                super(itemView);
//                titleTextView = itemView.findViewById(R.id.titleTV);
//                typeTV = itemView.findViewById(R.id.typeTV);
//            }
//
//            public void bind(Advert advert, final OnItemClickListener listener) {
//                titleTextView.setText(advert.getName());
//                typeTV.setText(advert.getLostType() ? "Lost" : "Found" );
//                itemView.setOnClickListener(new View.OnClickListener() {
//                    @Override public void onClick(View v) {
//                        listener.onItemClick(advert);
//                    }
//                });
//            }
//        }
//        @NonNull
//        @Override
//        public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
//            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.lnf_item, parent, false);
//            return new ViewHolder(view);
//        }
//
//        @Override
//        public void onBindViewHolder(ViewHolder holder, int position) {
//            Advert advert = advertList.get(position);
//            holder.bind(advert, listener);
//        }
//
//        @Override
//        public int getItemCount() {
//            if(this.advertList == null) {
//                System.out.println("getItemCount advertList is NULL");
//                return 0;
//            }
//            return this.advertList.size();
//        }
//    }
//}
//
//package com.example.task7_1;
//
//        import android.os.Bundle;
//        import android.view.View;
//        import android.widget.Button;
//        import android.widget.TextView;
//        import android.widget.Toast;
//
//        import androidx.appcompat.app.AppCompatActivity;
//
//public class AdvertDetails extends AppCompatActivity {
//    TextView typeTV;
//    TextView nameTV;
//    TextView phoneTV;
//    TextView descriptionTV;
//    TextView locationTV;
//    TextView dateTV;
//    Button removeButton;
//    Advert advert;
//    AdvertDB advertDB;
//    @Override
//    protected void onCreate(Bundle savedInstanceState) {
//        super.onCreate(savedInstanceState);
//        setContentView(R.layout.lnf_item_details);
//        advertDB = new AdvertDB(this);
//        typeTV = findViewById(R.id.typeTV);
//        nameTV = findViewById(R.id.nameTV);
//        phoneTV = findViewById(R.id.phoneTV);
//        descriptionTV = findViewById(R.id.descriptionTV);
//        dateTV = findViewById(R.id.dateTV);
//        locationTV = findViewById(R.id.locationTV);
//        removeButton = findViewById(R.id.removeButton);
//        String id = getIntent().getStringExtra("id");
//        advert = advertDB.getAdvert(id);
//
//        typeTV.setText(advert.getLostType() ? "Lost" : "Found");
//        nameTV.setText("Name: " + advert.getName());
//        phoneTV.setText("Phone: " + advert.getPhone());
//        descriptionTV.setText("Description: " + advert.getDescription());
//        dateTV.setText("Date: " + advert.getDate());
//        locationTV.setText("Location: " + advert.getLocation());
//
//        removeButton.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//
//                Boolean result = advertDB.deleteAdvert(id);
//                if (result) {
//                    Toast.makeText(AdvertDetails.this, "Successfully deleted item",
//                            Toast.LENGTH_SHORT).show();
//                    AdvertDetails.this.finish();
//                } else {
//                    Toast.makeText(AdvertDetails.this, "Item deletion error",
//                            Toast.LENGTH_SHORT).show();
//                }
//            }
//        });
//    }
//
//}
//
//
//package com.example.task7_1;
//
//public class Advert {
//    private String id;
//    private Boolean lostType;
//    private String name;
//    private String phone;
//    private String description;
//    private String date;
//    private String location;
//
//
//    public Advert(String id, Boolean lostType, String name, String phone, String description, String date, String location) {
//        this.id = id;
//        this.lostType = lostType;
//        this.name = name;
//        this.phone = phone;
//        this.description = description;
//        this.date = date;
//        this.location = location;
//    }
//
//    @Override
//    public String toString() {
//        return "Advert{" +
//                "id='" + id + '\'' +
//                ", lostType=" + lostType +
//                ", name='" + name + '\'' +
//                ", phone='" + phone + '\'' +
//                ", description='" + description + '\'' +
//                ", date='" + date + '\'' +
//                ", location='" + location + '\'' +
//                '}';
//    }
//
//    public String getId() {
//        return id;
//    }
//
//    public void setId(String id) {
//        this.id = id;
//    }
//
//    public Boolean getLostType() {
//        return lostType;
//    }
//
//    public void setLostType(Boolean lostType) {
//        this.lostType = lostType;
//    }
//
//    public String getName() {
//        return name;
//    }
//
//    public void setName(String name) {
//        this.name = name;
//    }
//
//    public String getPhone() {
//        return phone;
//    }
//
//    public void setPhone(String phone) {
//        this.phone = phone;
//    }
//
//    public String getDescription() {
//        return description;
//    }
//
//    public void setDescription(String description) {
//        this.description = description;
//    }
//
//    public String getDate() {
//        return date;
//    }
//
//    public void setDate(String date) {
//        this.date = date;
//    }
//
//    public String getLocation() {
//        return location;
//    }
//
//    public void setLocation(String location) {
//        this.location = location;
//    }
//}
